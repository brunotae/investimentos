-- ============================================
-- Fundo T&N · Versão 4 — rodar 1 vez
-- Supabase → SQL Editor → New query → colar → Run
-- ============================================

-- 1) Pista (linha do tempo) de cada frente
alter table public.invest_frentes add column if not exists etapas text[] default '{}';
alter table public.invest_frentes add column if not exists etapa int default 0;
alter table public.invest_frentes add column if not exists etapa_desde date;

-- 2) Moeda estrangeira nos lançamentos
alter table public.invest_mov add column if not exists moeda text default 'BRL';
alter table public.invest_mov add column if not exists cambio numeric(12,4);
alter table public.invest_mov add column if not exists valor_me numeric(14,2);

-- 3) Etapas iniciais (dá para mudar em Ajustes)
update public.invest_frentes set etapas = array['Aporte','Remessa / câmbio','Compra na Coreia','Envio','Alfândega','Estoque no site','Vendas','Retorno'] where nome ilike 'OMG%';
update public.invest_frentes set etapas = array['Planejamento','Aporte','Produção','Rótulo e registro','Lançamento','Vendas','Retorno'] where nome ilike 'San Martino%';
update public.invest_frentes set etapas = array['Estruturação','Equipamentos','Primeiros clientes','Contratos recorrentes','Escala','Retorno'] where nome ilike 'Automação%';
update public.invest_frentes set etapas = array['Escolha do produto','Fornecedor','Amostra','Produção','Live commerce','Retorno'] where nome ilike 'Marcas%';

-- 4) Os R$ 200 mil enviados para a Coreia (compra de cosméticos) a R$ 5,80
insert into public.invest_mov (data, tipo, frente_id, valor, moeda, cambio, valor_me, descricao)
select date '2026-11-12', 'investimento', id, 200000, 'USD', 5.80, round(200000/5.80, 2),
       'Remessa para a Coreia · compra de cosméticos'
from public.invest_frentes where nome ilike 'OMG%' limit 1;

-- carrinho da OMG na casa "Compra na Coreia"
update public.invest_frentes set etapa = 2, etapa_desde = date '2026-11-12' where nome ilike 'OMG%';
